
# Sky Ace — Avvio immediato

Questa build **parte subito** dentro il gioco (niente schermata iniziale).  
Auto‑Fire attivo di default su mobile. Audio disattivato finché non premi 🔊 (per policy mobile).

Controlli:
- **Tablet/Phone:** stick virtuale a sinistra, tocco a destra per fuoco, **Auto‑Fire** ON di default.
- **Desktop:** WASD/Frecce = muovi, Spazio = fuoco, ⏸ pausa, 🔊 audio.
