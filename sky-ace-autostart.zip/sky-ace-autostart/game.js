
(() => {
  'use strict';

  const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
  const rand = (a=0, b=1) => a + Math.random()*(b-a);
  const chance = p => Math.random() < p;
  const now = () => performance.now();
  const DPR = Math.min(2, window.devicePixelRatio || 1);

  const images = {
    player: 'assets/player.png',
    enemy: 'assets/enemy.png',
    boss: 'assets/boss.png',
    bullet: 'assets/bullet.png',
    enemyBullet: 'assets/enemy_bullet.png',
    powerup: 'assets/powerup.png',
    bg1: 'assets/bg1.jpg',
    bg2: 'assets/bg2.jpg'
  };
  const loaded = {};
  function loadImage(name, src) {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => resolve({ name, img });
      img.onerror = () => resolve({ name, img: null });
      img.src = src;
    });
  }
  async function loadAssets() {
    const entries = Object.entries(images).map(([n, s]) => loadImage(n, s));
    const res = await Promise.all(entries);
    res.forEach(({ name, img }) => (loaded[name] = img));
  }

  const keys = new Set();
  window.addEventListener('keydown', e => keys.add(e.code));
  window.addEventListener('keyup', e => keys.delete(e.code));

  const stick = {active:false, id:null, startX:0, startY:0, dx:0, dy:0};
  const fireTouch = {active:false, id:null};

  function setupTouch() {
    const stickZone = document.getElementById('stickZone');
    const fireZone = document.getElementById('fireZone');
    function onStart(e, zone) {
      for (const t of e.changedTouches) {
        if (!stick.active && zone === 'stick') {
          stick.active = true; stick.id = t.identifier; stick.startX = t.clientX; stick.startY = t.clientY; stick.dx = 0; stick.dy = 0;
        } else if (!fireTouch.active && zone === 'fire') {
          fireTouch.active = true; fireTouch.id = t.identifier;
        }
      }
    }
    function onMove(e) {
      for (const t of e.changedTouches) {
        if (stick.active && t.identifier === stick.id) {
          stick.dx = t.clientX - stick.startX;
          stick.dy = t.clientY - stick.startY;
        }
      }
    }
    function onEnd(e) {
      for (const t of e.changedTouches) {
        if (stick.active && t.identifier === stick.id) { stick.active = false; stick.id = null; stick.dx = stick.dy = 0; }
        if (fireTouch.active && t.identifier === fireTouch.id) { fireTouch.active = false; fireTouch.id = null; }
      }
    }
    stickZone.addEventListener('touchstart', e => { onStart(e,'stick'); }, {passive:true});
    stickZone.addEventListener('touchmove', e => { onMove(e); }, {passive:true});
    stickZone.addEventListener('touchend', e => { onEnd(e); }, {passive:true});
    stickZone.addEventListener('touchcancel', e => { onEnd(e); }, {passive:true});
    fireZone.addEventListener('touchstart', e => { onStart(e,'fire'); }, {passive:true});
    fireZone.addEventListener('touchend', e => { onEnd(e); }, {passive:true});
    fireZone.addEventListener('touchcancel', e => { onEnd(e); }, {passive:true});
  }

  // Audio off by default until user interacts (mobile policy); togglable with button
  let audioCtx = null, audioOn = false;
  function initAudio() {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  }
  function beep({freq=440, dur=0.06, type='square', gain=0.04}) {
    if (!audioOn) return;
    initAudio();
    const o = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    o.type = type; o.frequency.setValueAtTime(freq, audioCtx.currentTime);
    g.gain.value = gain;
    o.connect(g).connect(audioCtx.destination);
    o.start();
    o.stop(audioCtx.currentTime + dur);
  }
  const sfx = {
    shot(){beep({freq:800,type:'square',dur:0.04,gain:0.03});},
    enemyShot(){beep({freq:520,type:'square',dur:0.05,gain:0.03});},
    hit(){beep({freq:220,type:'sawtooth',dur:0.06,gain:0.05});},
    power(){beep({freq:1000,type:'triangle',dur:0.08,gain:0.05});},
    boom(){beep({freq:120,type:'sawtooth',dur:0.25,gain:0.06});}
  };

  class Sprite {
    constructor(w, h) { this.w = w; this.h = h; }
    draw(ctx, x, y, img, fallback) {
      if (img) ctx.drawImage(img, x - this.w/2, y - this.h/2, this.w, this.h);
      else fallback(ctx, x, y, this.w, this.h);
    }
  }
  const fallbackSprites = {
    player(ctx, x, y, w, h){
      ctx.save(); ctx.translate(x,y);
      ctx.fillStyle = '#cfd8e3'; ctx.beginPath(); ctx.moveTo(0,-h*0.5); ctx.quadraticCurveTo(w*0.2,0, 0,h*0.5); ctx.quadraticCurveTo(-w*0.2,0, 0,-h*0.5); ctx.fill();
      ctx.fillStyle = '#79a8ff'; ctx.beginPath(); ctx.ellipse(0,-h*0.1, w*0.18, h*0.14, 0, 0, Math.PI*2); ctx.fill();
      ctx.fillStyle = '#b0bac7'; ctx.fillRect(-w*0.55, -h*0.05, w*1.1, h*0.12);
      ctx.restore();
    },
    enemy(ctx, x, y, w, h){
      ctx.save(); ctx.translate(x,y);
      ctx.fillStyle = '#9f4b4b'; ctx.beginPath(); ctx.ellipse(0,0, w*0.4,h*0.5, 0,0,Math.PI*2); ctx.fill();
      ctx.fillStyle = '#6b2e2e'; ctx.fillRect(-w*0.6,-h*0.06,w*1.2,h*0.12);
      ctx.restore();
    },
    boss(ctx, x, y, w, h){
      ctx.save(); ctx.translate(x,y);
      ctx.fillStyle = '#444'; ctx.fillRect(-w*0.6,-h*0.4,w*1.2,h*0.8);
      ctx.fillStyle = '#666'; ctx.fillRect(-w*0.8,-h*0.08,w*1.6,h*0.16);
      ctx.restore();
    },
    bullet(ctx, x, y, w, h){
      ctx.save(); ctx.translate(x,y);
      ctx.fillStyle = '#ffd56b'; ctx.fillRect(-w*0.15,-h*0.45, w*0.3, h*0.9);
      ctx.restore();
    },
    enemyBullet(ctx, x, y, w, h){
      ctx.save(); ctx.translate(x,y);
      ctx.fillStyle = '#ff7a7a'; ctx.beginPath(); ctx.arc(0,0,Math.max(2,w*0.12),0,Math.PI*2); ctx.fill();
      ctx.restore();
    },
    powerup(ctx, x, y, w, h){
      ctx.save(); ctx.translate(x,y);
      ctx.strokeStyle = '#7cffd0'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(0,0,Math.max(8,w*0.35),0,Math.PI*2); ctx.stroke();
      ctx.restore();
    }
  };

  class Entity {
    constructor(x,y,vx=0,vy=0){this.x=x;this.y=y;this.vx=vx;this.vy=vy;this.dead=false;}
    update(dt){this.x+=this.vx*dt; this.y+=this.vy*dt;}
    draw(ctx){}
  }
  class Bullet extends Entity{
    constructor(x,y,vy,enemy=false){super(x,y,0,vy); this.enemy=enemy; this.r = enemy?7:6; this.sprite = new Sprite(10,20);}
    draw(ctx){
      const img = this.enemy ? loaded.enemyBullet : loaded.bullet;
      const fb = this.enemy ? fallbackSprites.enemyBullet : fallbackSprites.bullet;
      this.sprite.draw(ctx, this.x, this.y, img, fb);
    }
  }
  class PowerUp extends Entity{
    constructor(x,y){super(x,y,0,60); this.r=12; this.sprite = new Sprite(28,28);}
    draw(ctx){ this.sprite.draw(ctx, this.x, this.y, loaded.powerup, fallbackSprites.powerup);}
  }
  class Enemy extends Entity{
    constructor(x,y,speed=60,hp=2){super(x,y,0,speed); this.r=18; this.hp=hp; this.t=0; this.sprite = new Sprite(44,44);}
    update(dt, game){
      super.update(dt); this.t += dt;
      this.x += Math.sin(this.t*2)*20*dt;
      if (chance(0.01)) game.spawnEnemyBullet(this.x, this.y+16, 160+rand(-20,20));
      if (this.y > game.h + 40) this.dead = true;
    }
    hit(game){
      this.hp--; sfx.hit();
      if (this.hp<=0){
        this.dead = true; game.explode(this.x,this.y);
        if (Math.random()<0.15) game.entities.push(new PowerUp(this.x,this.y));
        game.addScore(100);
      }
    }
    draw(ctx){ this.sprite.draw(ctx, this.x, this.y, loaded.enemy, fallbackSprites.enemy);}
  }
  class Boss extends Entity{
    constructor(x,y){super(x,y,0,18); this.r=50; this.hp=120; this.sprite = new Sprite(140,110); this.t=0; this.entered=false;}
    update(dt, game){
      this.t += dt;
      if (!this.entered){
        this.y += 30*dt;
        if (this.y > 120) this.entered = true;
      } else {
        this.x += Math.sin(this.t*0.8)*60*dt;
        if ((game.time|0) % 2 === 0 && Math.random()<0.06) {
          for (let i=-2;i<=2;i++){ game.spawnEnemyBullet(this.x+i*18, this.y+40, 220+Math.abs(i)*8); }
        }
        if ((game.time|0) % 3 === 0 && Math.random()<0.04){
          for (let i=0;i<8;i++) setTimeout(()=>game.spawnEnemyBullet(this.x+Math.sin(i)*30,this.y+30,180+ i*6), i*30);
        }
      }
      if (this.y > game.h + 80) this.dead = true;
    }
    hit(game){
      this.hp--; sfx.hit();
      if (this.hp<=0){
        this.dead = true; game.explode(this.x,this.y,60);
        game.addScore(5000);
        game.queueBoss = false;
        setTimeout(()=>game.queueBoss=true, 25000);
      }
    }
    draw(ctx){ this.sprite.draw(ctx, this.x, this.y, loaded.boss, fallbackSprites.boss);}
  }
  class Player extends Entity{
    constructor(game){
      super(game.w/2, game.h-100, 0, 0);
      this.game = game; this.r = 18; this.speed = 240;
      this.fireCooldown = 0; this.power = 1; this.sprite = new Sprite(52,64); this.autofire = true; // enable autofire by default for mobile
    }
    update(dt){
      const g = this.game; let ax=0, ay=0;
      if (keys.has('ArrowLeft') || keys.has('KeyA')) ax -= 1;
      if (keys.has('ArrowRight') || keys.has('KeyD')) ax += 1;
      if (keys.has('ArrowUp') || keys.has('KeyW')) ay -= 1;
      if (keys.has('ArrowDown') || keys.has('KeyS')) ay += 1;
      if (stick.active){
        const dead = 12; const len = Math.hypot(stick.dx, stick.dy);
        const nx = len>dead ? stick.dx/Math.max(len,1) : 0;
        const ny = len>dead ? stick.dy/Math.max(len,1) : 0;
        ax += nx; ay += ny;
      }
      const l = Math.hypot(ax,ay) || 1;
      this.vx = (ax/l) * this.speed;
      this.vy = (ay/l) * this.speed;
      super.update(dt);
      this.x = clamp(this.x, 20, g.w-20);
      this.y = clamp(this.y, 40, g.h-40);
      this.fireCooldown -= dt;
      const wantFire = keys.has('Space') || fireTouch.active || this.autofire;
      if (wantFire && this.fireCooldown <= 0){ this.fire(); }
    }
    fire(){
      const g = this.game; const spread = Math.min(4, this.power); const baseVy = -420;
      if (spread === 1){ g.entities.push(new Bullet(this.x, this.y-24, baseVy)); }
      else { for (let i=0;i<spread;i++){ const off = (i - (spread-1)/2) * 14; g.entities.push(new Bullet(this.x + off, this.y-24, baseVy)); } }
      sfx.shot(); this.fireCooldown = Math.max(0.08, 0.2 - this.power*0.02);
    }
    upgrade(){ this.power = Math.min(6, this.power+1); sfx.power(); }
    draw(ctx){ this.sprite.draw(ctx, this.x, this.y, loaded.player, fallbackSprites.player);}
  }

  class Background {
    constructor(w,h){
      this.w=w; this.h=h;
      this.layers = [{img: loaded.bg1, speed: 12, y:0},{img: loaded.bg2, speed: 22, y:0}];
      this.stars = Array.from({length:120}, () => ({x:rand(0,w), y:rand(0,h), r:rand(0.4,1.6), s:rand(10,40)}));
      this.clouds = Array.from({length:8}, () => ({x:rand(0,w), y:rand(0,h), w:rand(120,260), h:rand(40,90), s:rand(8,16), a:rand(0.08,0.18)}));
    }
    update(dt){
      for (const l of this.layers){ l.y += l.speed*dt; if (l.y > this.h) l.y -= this.h; }
      for (const s of this.stars){ s.y += s.s*dt; if (s.y>this.h) s.y=0; }
      for (const c of this.clouds){ c.y += c.s*dt; if (c.y>this.h+80) c.y=-80; }
    }
    draw(ctx){
      ctx.save(); ctx.fillStyle='#06101c'; ctx.fillRect(0,0,this.w,this.h);
      if (loaded.bg1){
        for (const l of this.layers){
          const y = (l.y|0);
          ctx.drawImage(l.img, 0, y - this.h, this.w, this.h);
          ctx.drawImage(l.img, 0, y, this.w, this.h);
        }
      } else {
        ctx.globalAlpha = 0.9;
        for (const s of this.stars){ ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, Math.PI*2); ctx.fillStyle='white'; ctx.fill(); }
        ctx.globalAlpha = 1;
        for (const c of this.clouds){
          const grad = ctx.createRadialGradient(c.x, c.y, 10, c.x, c.y, Math.max(c.w,c.h));
          grad.addColorStop(0, `rgba(255,255,255,${c.a})`);
          grad.addColorStop(1, `rgba(255,255,255,0)`);
          ctx.fillStyle = grad; ctx.beginPath(); ctx.ellipse(c.x,c.y,c.w,c.h,0,0,Math.PI*2); ctx.fill();
        }
      }
      ctx.restore();
    }
  }
  class Particle extends Entity{
    constructor(x,y,vx,vy,life=0.7){ super(x,y,vx,vy); this.life=life; this.t=0; this.size=rand(4,10); }
    update(dt){ super.update(dt); this.t += dt; if (this.t > this.life) this.dead = true; }
    draw(ctx){ const a = 1 - (this.t/this.life); ctx.fillStyle = `rgba(255,180,100,${a})`; ctx.beginPath(); ctx.arc(this.x, this.y, this.size*(0.6+a*0.6), 0, Math.PI*2); ctx.fill(); }
  }

  class Game {
    constructor(canvas){
      this.c = canvas; this.ctx = canvas.getContext('2d');
      this.w = canvas.width; this.h = canvas.height;
      this.time = 0; this.entities = []; this.player = new Player(this); this.entities.push(this.player);
      this.bg = new Background(this.w, this.h);
      this.running = false; this.last = 0; this.score = 0; this.queueBoss = false; this.spawnTimer = 0; this.autoSpawn = true;
      this.bindUI();
    }
    bindUI(){
      const scoreEl = document.getElementById('score');
      const pauseBtn = document.getElementById('btnPause');
      const soundBtn = document.getElementById('btnSound');
      const btnAuto = document.getElementById('btnAutoFire');
      pauseBtn.onclick = () => { this.running = !this.running; if (this.running) this.loop(); };
      soundBtn.onclick = () => { audioOn = !audioOn; if (audioOn) initAudio(); soundBtn.textContent = audioOn ? '🔊' : '🔇'; };
      btnAuto.onclick = () => { this.player.autofire = !this.player.autofire; btnAuto.classList.toggle('primary', this.player.autofire); };
      this.updateScore = () => scoreEl.textContent = String(this.score).padStart(6,'0');
    }
    addScore(v){ this.score += v; this.updateScore(); }
    start(){ this.running = true; this.last = now(); this.loop(); setTimeout(()=> this.queueBoss = true, 30000); }
    explode(x,y,p=28){
      for (let i=0;i<p;i++){ const a = rand(0, Math.PI*2); const s = rand(40, 180);
        this.entities.push(new Particle(x,y, Math.cos(a)*s, Math.sin(a)*s, rand(0.4,0.9))); }
      if (audioOn) sfx.boom();
    }
    spawnEnemy(){ const x = rand(40, this.w-40); const y = -30; this.entities.push(new Enemy(x,y, rand(60,90), Math.random()<0.25?3:2)); }
    spawnEnemyBullet(x,y,vy){ this.entities.push(new Bullet(x,y,vy,true)); if (audioOn) sfx.enemyShot(); }
    spawnBoss(){ this.entities.push(new Boss(this.w/2, -120)); }
    loop(){
      if (!this.running) return;
      const t = now(); const dt = Math.min(0.033, (t - this.last)/1000); this.last = t; this.time += dt;
      this.update(dt); this.render(); requestAnimationFrame(() => this.loop());
    }
    update(dt){
      this.bg.update(dt);
      this.spawnTimer -= dt; if (this.spawnTimer <= 0){ this.spawnEnemy(); this.spawnTimer = rand(0.4, 1.0); }
      if (this.queueBoss){ this.spawnBoss(); this.queueBoss=false; }
      for (const e of this.entities){ if (e instanceof Enemy) e.update(dt, this); else if (e instanceof Boss) e.update(dt, this); else e.update(dt); }
      const bullets = this.entities.filter(e => e instanceof Bullet && !e.enemy);
      for (const b of bullets){
        for (const e of this.entities){
          if ((e instanceof Enemy || e instanceof Boss) && !e.dead){
            if (Math.hypot(b.x-e.x,b.y-e.y) < (e.r + 10)){ b.dead=true; e.hit(this); break; }
          }
        }
      }
      const eBullets = this.entities.filter(e => e instanceof Bullet && e.enemy);
      for (const eb of eBullets){ if (Math.hypot(eb.x-this.player.x, eb.y-this.player.y) < (this.player.r+6)){ eb.dead = true; this.playerHit(); } }
      for (const e of this.entities){
        if ((e instanceof Enemy || e instanceof Boss) && !e.dead){
          if (Math.hypot(e.x-this.player.x, e.y-this.player.y) < (this.player.r + e.r - 6)){ e.dead = true; this.playerHit(); }
        }
      }
      for (const pu of this.entities.filter(e => e instanceof PowerUp)){
        if (Math.hypot(pu.x-this.player.x, pu.y-this.player.y) < (this.player.r + pu.r)){ pu.dead = true; this.player.upgrade(); }
      }
      this.entities = this.entities.filter(e => !e.dead && e.y>-140 && e.y<this.h+180 && e.x>-180 && e.x<this.w+180);
    }
    playerHit(){
      this.explode(this.player.x, this.player.y, 36);
      this.player.x = this.w/2; this.player.y = this.h-100;
      this.player.power = Math.max(1, this.player.power-1);
      this.addScore(Math.max(0, -250));
    }
    render(){
      const ctx = this.ctx; ctx.save();
      ctx.setTransform(DPR,0,0,DPR,0,0);
      this.bg.draw(ctx);
      const g = ctx.createLinearGradient(0,0,0,this.h);
      g.addColorStop(0,'rgba(0,0,0,0.3)'); g.addColorStop(0.2,'rgba(0,0,0,0)'); g.addColorStop(1,'rgba(0,0,0,0.25)');
      ctx.fillStyle=g; ctx.fillRect(0,0,this.w,this.h);
      for (const e of this.entities) e.draw(ctx);
      ctx.restore();
    }
  }

  async function main(){
    const canvas = document.getElementById('game');
    const w = 540, h = 960;
    const DPRv = Math.min(2, window.devicePixelRatio || 1);
    canvas.width = w * DPRv; canvas.height = h * DPRv;
    canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    setupTouch();
    await loadAssets();
    const game = new Game(canvas);
    // Autofocus canvas for keyboard users; start immediately
    setTimeout(()=>canvas.focus(), 0);
    game.start();
  }

  const manifest = {
    "name":"Sky Ace","short_name":"Sky Ace","display":"standalone","start_url":"./index.html","icons":[],
    "background_color":"#0a0f1a","theme_color":"#0a0f1a","orientation":"portrait"
  };
  const blob = new Blob([JSON.stringify(manifest,null,2)], {type:'application/json'});
  const link = document.createElement('link'); link.setAttribute('rel','manifest'); link.setAttribute('href', URL.createObjectURL(blob));
  document.head.appendChild(link);

  window.addEventListener('load', main);
})();
